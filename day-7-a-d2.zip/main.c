/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int i, j, sum;
    printf("Perfect numbers between 1 to 100:\n");
    for (i = 1; i <= 100; i++) 
    {
        sum = 0;
        for (j = 1; j < i; j++) 
        {
            if (i % j == 0) 
            {
                sum += j;
            }
        }
        if (sum == i) 
        {
            printf("%d\n", i);
        }
    }
    return 0;
}
