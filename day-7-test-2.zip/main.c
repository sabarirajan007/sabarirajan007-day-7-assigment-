/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
int main()
{
    char string[50], ch='$', i;
    printf("Enter any string: ");
    scanf("%s",string);
    {
        for(i=0; string[i]!='\0'; i++)
        {   
            if(string[i]=='a' || string[i]=='e' || string[i]=='i' || string[i]=='o'
            || string[i]=='u' || string[i]=='A' || string[i]=='E' || string[i]=='I'
            || string[i]=='O' || string[i]=='U')
            {
                string[i] = ch;
            }
        }
        printf("\nReplaced String with %c = %s", ch, string);
    }
        return 0;
}















    
        
     
